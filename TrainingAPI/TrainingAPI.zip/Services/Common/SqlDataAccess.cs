using Microsoft.Data.SqlClient;
using System.Data;

namespace TrainingAPI.Services.Common
{
    /// <summary>
    /// [2.1][Encapsulation] Hiện thực duy nhất của ISqlDataAccess trong
    /// toàn bộ project. Sau đợt refactor này, đây là NƠI DUY NHẤT còn
    /// gọi "new SqlConnection(...)" - mọi Controller/Hub khác chỉ còn
    /// biết tới interface ISqlDataAccess.
    ///
    /// [2.2][DI - đăng ký ở Program.cs] Đăng ký Scoped: mỗi request có
    /// một chuỗi kết nối cố định trong suốt request đó, tương tự vòng
    /// đời của DbContext, dù ở đây mỗi lệnh vẫn tự mở/đóng connection
    /// riêng (không dùng chung 1 connection giữa các lệnh trong cùng
    /// request) để tránh phải quản lý transaction dùng chung phức tạp
    /// ở tầng này.
    /// </summary>
    public class SqlDataAccess : ISqlDataAccess
    {
        private readonly string _connectionString;

        public SqlDataAccess(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                ?? throw new InvalidOperationException("Thiếu cấu hình ConnectionStrings:DefaultConnection.");
        }

        private static SqlCommand CreateCommand(
            SqlConnection connection,
            string commandText,
            CommandType commandType,
            Action<SqlParameterCollection>? configureParameters)
        {
            var command = new SqlCommand(commandText, connection) { CommandType = commandType };
            configureParameters?.Invoke(command.Parameters);
            return command;
        }

        public async Task<int> ExecuteNonQueryAsync(
            string storedProcedure,
            Action<SqlParameterCollection>? configureParameters = null,
            CancellationToken cancellationToken = default)
        {
            await using var connection = new SqlConnection(_connectionString);
            await using var command = CreateCommand(connection, storedProcedure, CommandType.StoredProcedure, configureParameters);

            await connection.OpenAsync(cancellationToken);
            return await command.ExecuteNonQueryAsync(cancellationToken);
        }

        public async Task<int> ExecuteRawNonQueryAsync(
            string sqlText,
            Action<SqlParameterCollection>? configureParameters = null,
            CancellationToken cancellationToken = default)
        {
            await using var connection = new SqlConnection(_connectionString);
            await using var command = CreateCommand(connection, sqlText, CommandType.Text, configureParameters);

            await connection.OpenAsync(cancellationToken);
            return await command.ExecuteNonQueryAsync(cancellationToken);
        }

        public async Task<T?> ExecuteScalarAsync<T>(
            string storedProcedure,
            Action<SqlParameterCollection>? configureParameters = null,
            CancellationToken cancellationToken = default)
        {
            await using var connection = new SqlConnection(_connectionString);
            await using var command = CreateCommand(connection, storedProcedure, CommandType.StoredProcedure, configureParameters);

            await connection.OpenAsync(cancellationToken);
            var result = await command.ExecuteScalarAsync(cancellationToken);

            if (result is null || result is DBNull) return default;
            return (T)Convert.ChangeType(result, typeof(T));
        }

        public async Task<SqlReaderResult> ExecuteReaderAsync(
            string storedProcedure,
            Action<SqlParameterCollection>? configureParameters = null,
            CancellationToken cancellationToken = default)
        {
            // KHÔNG dùng "await using" ở đây: nếu mở thành công, quyền sở
            // hữu connection được CHUYỂN GIAO cho SqlReaderResult, người
            // gọi (Controller/Hub) mới là nơi chịu trách nhiệm dispose nó.
            var connection = new SqlConnection(_connectionString);
            try
            {
                var command = CreateCommand(connection, storedProcedure, CommandType.StoredProcedure, configureParameters);
                await connection.OpenAsync(cancellationToken);

                // CommandBehavior.CloseConnection: khi reader bị dispose,
                // connection tự đóng theo - lớp bảo vệ thứ hai bên cạnh
                // việc SqlReaderResult tự dispose cả hai.
                var reader = await command.ExecuteReaderAsync(CommandBehavior.CloseConnection, cancellationToken);
                return new SqlReaderResult(connection, reader);
            }
            catch
            {
                await connection.DisposeAsync();
                throw;
            }
        }
    }
}
