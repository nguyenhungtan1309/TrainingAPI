using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using TrainingAPI.DTOs;
using TrainingAPI.Models;
using TrainingAPI.Services.Common;

namespace TrainingAPI.Controllers
{
    [ApiController]
    [Route("api/v1/users")]
    public class UserController : ControllerBase
    {
        private readonly CompanyContext _context;
        private readonly ISqlDataAccess _sql;
        private readonly IPasswordHasher _passwordHasher;

        // [Hạ tầng chung] Không còn giữ _connectionString hay tự xây dựng
        // nó từ IConfiguration nữa - ISqlDataAccess lo toàn bộ việc đó.
        public UserController(CompanyContext context, ISqlDataAccess sql, IPasswordHasher passwordHasher)
        {
            _context = context;
            _sql = sql;
            _passwordHasher = passwordHasher;
        }

        [HttpPost("block")]
        public async Task<IActionResult> ToggleBlockUser([FromQuery] int userId, [FromBody] ToggleBlockRequestDTO request)
        {
            try
            {
                await _sql.ExecuteNonQueryAsync("dbo.sp_ToggleBlockUser", p =>
                {
                    p.AddWithValue("@UserId", userId);
                    p.AddWithValue("@BlockedUserId", request.BlockedUserId);
                });

                return Ok(new { success = true });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("device-token")]
        public async Task<IActionResult> RegisterDevice([FromQuery] int userId, [FromBody] RegisterDeviceRequestDTO request)
        {
            try
            {
                await _sql.ExecuteNonQueryAsync("dbo.sp_RegisterDevice", p =>
                {
                    p.AddWithValue("@UserId", userId);
                    p.AddWithValue("@DeviceToken", request.DeviceToken);
                    p.AddWithValue("@Platform", request.Platform);
                });

                return Ok(new { success = true });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("profile")]
        public async Task<IActionResult> UpdateProfile([FromQuery] int userId, [FromBody] UpdateProfileRequestDTO request)
        {
            var user = await _context.AppUsers.FirstOrDefaultAsync(u => u.Id == userId);

            if (user == null || !user.IsActive)
                return NotFound(new { message = "Người dùng không tồn tại hoặc đã bị khóa." });

            // [2.1][Encapsulation] Không gán trực tiếp user.DisplayName/AvatarUrl
            // nữa - validate được đảm bảo ở đúng MỘT chỗ, bên trong AppUser.
            user.UpdateProfile(request.DisplayName, request.AvatarUrl);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                success = true,
                displayName = user.DisplayName,
                avatarUrl = user.AvatarUrl
            });
        }

        [HttpPut("change-password")]
        public async Task<IActionResult> ChangePassword([FromQuery] int userId, [FromBody] ChangePasswordRequestDTO request)
        {
            var user = await _context.AppUsers.FirstOrDefaultAsync(u => u.Id == userId);

            if (user == null || !user.IsActive)
                return NotFound(new { message = "Người dùng không tồn tại hoặc đã bị khóa." });

            if (!_passwordHasher.Verify(request.OldPassword, user.PasswordSalt, user.PasswordHash))
            {
                return BadRequest(new { message = "Mật khẩu cũ không chính xác." });
            }

            var newSalt = _passwordHasher.GenerateSalt();
            var newHash = _passwordHasher.Hash(request.NewPassword, newSalt);
            user.ChangePassword(newHash, newSalt);

            await _context.SaveChangesAsync();

            return Ok(new { success = true, message = "Đổi mật khẩu thành công." });
        }
    }
}
