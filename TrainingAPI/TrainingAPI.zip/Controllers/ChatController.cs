using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Text.Json;
using TrainingAPI.DTOs;
using TrainingAPI.Models;
using TrainingAPI.Services.Common;
using TrainingAPI.Services.Messaging.Validation;

namespace TrainingAPI.Controllers
{
    [ApiController]
    [Route("api/v1/chat")]
    public class ChatController : ControllerBase
    {
        private readonly CompanyContext _context;
        private readonly ISqlDataAccess _sql;

        // [Hạ tầng chung] Trước đây: private readonly string _connectionString,
        // được xây dựng lại y hệt trong constructor của MỌI Controller.
        // Giờ chỉ còn nhận ISqlDataAccess qua Constructor Injection.
        public ChatController(CompanyContext context, ISqlDataAccess sql)
        {
            _context = context;
            _sql = sql;
        }

        [HttpGet("conversations")]
        public async Task<IActionResult> GetConversations([FromQuery] int viewerId)
        {
            var conversations = new List<ConversationDTO>();

            await using var result = await _sql.ExecuteReaderAsync("dbo.sp_GetConversationList", p =>
            {
                p.AddWithValue("@ViewerId", viewerId);
            });

            var reader = result.Reader;
            while (await reader.ReadAsync())
            {
                conversations.Add(new ConversationDTO
                {
                    ViewerId = reader.GetInt32("ViewerId"),
                    ThreadId = reader.GetInt64("ThreadId"),
                    IsGroup = reader.GetBoolean("IsGroup"),
                    ThreadName = reader.IsDBNull("ThreadName") ? "Cuộc hội thoại" : reader.GetString("ThreadName"),
                    ThreadAvatarUrl = reader.IsDBNull("ThreadAvatarUrl") ? null : reader.GetString("ThreadAvatarUrl"),
                    LastMessageId = reader.IsDBNull("LastMessageId") ? null : reader.GetInt64("LastMessageId"),
                    LastMessageContent = reader.IsDBNull("LastMessageContent") ? null : reader.GetString("LastMessageContent"),
                    LastSenderId = reader.IsDBNull("LastSenderId") ? null : reader.GetInt32("LastSenderId"),
                    LastMessageTimeUTC = reader.IsDBNull("LastMessageTimeUTC") ? null : reader.GetDateTime("LastMessageTimeUTC"),
                    LastDeliveredMessageId = reader.IsDBNull("LastDeliveredMessageId") ? null : reader.GetInt64("LastDeliveredMessageId"),
                    LastReadMessageId = reader.IsDBNull("LastReadMessageId") ? null : reader.GetInt64("LastReadMessageId"),
                    IsMuted = reader.GetBoolean("IsMuted")
                });
            }

            return Ok(conversations);
        }

        [HttpGet("messages")]
        public async Task<IActionResult> GetThreadMessages(
        [FromQuery] int viewerId,
        [FromQuery] long threadId,
        [FromQuery] long? cursorMessageId = null,
        [FromQuery] int limit = 20)
        {
            try
            {
                await using var result = await _sql.ExecuteReaderAsync("dbo.sp_GetThreadMessages", p =>
                {
                    p.AddWithValue("@ViewerId", viewerId);
                    p.AddWithValue("@ThreadId", threadId);
                    p.AddWithValue("@CursorMessageId", (object?)cursorMessageId ?? DBNull.Value);
                    p.AddWithValue("@Limit", limit);
                });

                var reader = result.Reader;
                var messagesMap = new Dictionary<long, MessageResponseDTO>();
                var messagesList = new List<MessageResponseDTO>();

                while (await reader.ReadAsync())
                {
                    var msg = new MessageResponseDTO
                    {
                        MessageId = reader.GetInt64("MessageId"),
                        SenderId = reader.GetInt32("SenderId"),
                        SenderName = reader.GetString("SenderName"),
                        SenderAvatarUrl = reader.IsDBNull("SenderAvatarUrl") ? null : reader.GetString("SenderAvatarUrl"),
                        MessageType = reader.GetString("MessageType"),
                        Content = reader.GetString("Content"),
                        IsRevoked = reader.GetBoolean("IsRevoked"),
                        IsEdited = reader.GetBoolean("IsEdited"),
                        SentAtUTC = reader.GetDateTime("SentAtUTC"),
                        ParentMessageId = reader.IsDBNull("ParentMessageId") ? null : reader.GetInt64("ParentMessageId"),
                        ParentSenderName = reader.IsDBNull("ParentSenderName") ? null : reader.GetString("ParentSenderName"),
                        ParentContent = reader.IsDBNull("ParentContent") ? null : reader.GetString("ParentContent"),
                        IsPinned = reader.GetBoolean("IsPinned"),
                        Attachments = new List<MessageAttachmentDTO>(),
                        Reactions = new List<MessageReactionDTO>()
                    };

                    messagesMap[msg.MessageId] = msg;
                    messagesList.Add(msg);
                }

                if (await reader.NextResultAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        long msgId = reader.GetInt64("MessageId");
                        if (messagesMap.TryGetValue(msgId, out var msg))
                        {
                            msg.Attachments.Add(new MessageAttachmentDTO
                            {
                                Id = reader.GetInt64("Id"),
                                FileUrl = reader.GetString("FileUrl"),
                                FileType = reader.GetString("FileType"),
                                FileSize = reader.GetInt32("FileSize")
                            });
                        }
                    }
                }

                if (await reader.NextResultAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        long msgId = reader.GetInt64("MessageId");
                        if (messagesMap.TryGetValue(msgId, out var msg))
                        {
                            msg.Reactions.Add(new MessageReactionDTO
                            {
                                ReactionType = reader.GetString("ReactionType"),
                                UserId = reader.GetInt32("UserId"),
                                ReactedByName = reader.GetString("ReactedByName")
                            });
                        }
                    }
                }

                return Ok(messagesList);
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpGet("users/search")]
        public async Task<IActionResult> SearchUsers([FromQuery] int currentUserId, [FromQuery] string keyword)
        {
            var result = new List<UserSearchDTO>();

            await using var readerResult = await _sql.ExecuteReaderAsync("dbo.sp_SearchUsersToChat", p =>
            {
                p.AddWithValue("@CurrentUserId", currentUserId);
                p.AddWithValue("@Keyword", keyword ?? string.Empty);
            });

            var reader = readerResult.Reader;
            while (await reader.ReadAsync())
            {
                result.Add(new UserSearchDTO(
                    reader.GetInt32("Id"),
                    reader.GetString("Username"),
                    reader.GetString("DisplayName"),
                    reader.IsDBNull("AvatarUrl") ? null : reader.GetString("AvatarUrl")
                ));
            }

            return Ok(result);
        }

        [HttpGet("threads/{threadId}/participants")]
        public async Task<IActionResult> GetParticipants([FromRoute] long threadId, [FromQuery] int viewerId)
        {
            var participants = new List<ParticipantDTO>();

            try
            {
                await using var result = await _sql.ExecuteReaderAsync("dbo.sp_GetThreadParticipants", p =>
                {
                    p.AddWithValue("@ViewerId", viewerId);
                    p.AddWithValue("@ThreadId", threadId);
                });

                var reader = result.Reader;
                while (await reader.ReadAsync())
                {
                    participants.Add(new ParticipantDTO
                    {
                        UserId = reader.GetInt32("UserId"),
                        Username = reader.GetString("Username"),
                        DisplayName = reader.GetString("DisplayName"),
                        AvatarUrl = reader.IsDBNull("AvatarUrl") ? null : reader.GetString("AvatarUrl"),
                        Role = reader.GetString("Role"),
                        JoinedAtUTC = reader.GetDateTime("JoinedAtUTC"),
                        LastDeliveredMessageId = reader.IsDBNull("LastDeliveredMessageId") ? null : reader.GetInt64("LastDeliveredMessageId"),
                        LastReadMessageId = reader.IsDBNull("LastReadMessageId") ? null : reader.GetInt64("LastReadMessageId")
                    });
                }

                return Ok(participants);
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("threads")]
        public async Task<IActionResult> CreateThread([FromQuery] int creatorId, [FromBody] CreateThreadRequestDTO request)
        {
            try
            {
                var newThreadId = await _sql.ExecuteScalarAsync<long>("dbo.sp_CreateThread", p =>
                {
                    p.AddWithValue("@CreatorId", creatorId);
                    p.AddWithValue("@IsGroup", request.IsGroup);
                    p.AddWithValue("@Title", (object?)request.Title ?? DBNull.Value);
                    p.AddWithValue("@ParticipantIdsJson", JsonSerializer.Serialize(request.ParticipantIds));
                });

                return Ok(new { threadId = newThreadId });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("messages")]
        public async Task<IActionResult> SendMessage([FromQuery] int senderId, [FromBody] SendMessageRequestDTO request)
        {
            var validator = MessageValidatorFactory.GetValidator(request.MessageType);
            var validationResult = validator.Validate(request);

            if (!validationResult.IsValid)
            {
                return BadRequest(new { success = false, message = validationResult.ErrorMessage });
            }

            try
            {
                var newMsgId = await _sql.ExecuteScalarAsync<long>("dbo.sp_SendMessage", p =>
                {
                    p.AddWithValue("@ThreadId", request.ThreadId);
                    p.AddWithValue("@SenderId", senderId);
                    p.AddWithValue("@MessageType", request.MessageType);
                    p.AddWithValue("@Content", request.Content);
                    p.AddWithValue("@ParentMessageId", (object?)request.ParentMessageId ?? DBNull.Value);
                    p.AddWithValue("@ForwardedFromMessageId", (object?)request.ForwardedFromMessageId ?? DBNull.Value);
                });

                return Ok(new { messageId = newMsgId });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("threads/{threadId}/read")]
        public async Task<IActionResult> MarkAsRead([FromRoute] long threadId, [FromQuery] int userId, [FromQuery] long messageId)
        {
            await _sql.ExecuteNonQueryAsync("dbo.sp_MarkAsRead", p =>
            {
                p.AddWithValue("@ThreadId", threadId);
                p.AddWithValue("@UserId", userId);
                p.AddWithValue("@MessageId", messageId);
            });

            return Ok(new { success = true });
        }

        [HttpPost("messages/reaction")]
        public async Task<IActionResult> ToggleReaction([FromQuery] int userId, [FromBody] ToggleReactionRequestDTO request)
        {
            try
            {
                await _sql.ExecuteNonQueryAsync("dbo.sp_ToggleReaction", p =>
                {
                    p.AddWithValue("@MessageId", request.MessageId);
                    p.AddWithValue("@UserId", userId);
                    p.AddWithValue("@ReactionType", request.ReactionType);
                });

                return Ok(new { success = true });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("messages/{messageId}/revoke")]
        public async Task<IActionResult> RevokeMessage([FromRoute] long messageId, [FromQuery] int userId)
        {
            await _sql.ExecuteNonQueryAsync("dbo.sp_RevokeMessage", p =>
            {
                p.AddWithValue("@MessageId", messageId);
                p.AddWithValue("@UserId", userId);
            });

            return Ok(new { success = true });
        }

        [HttpPut("messages/{messageId}")]
        public async Task<IActionResult> EditMessage([FromRoute] long messageId, [FromQuery] int userId, [FromBody] EditMessageRequestDTO request)
        {
            await _sql.ExecuteNonQueryAsync("dbo.sp_EditMessage", p =>
            {
                p.AddWithValue("@MessageId", messageId);
                p.AddWithValue("@UserId", userId);
                p.AddWithValue("@NewContent", request.NewContent);
            });

            return Ok(new { success = true });
        }

        [HttpPost("threads/{threadId}/pin/{messageId}")]
        public async Task<IActionResult> TogglePin([FromRoute] long threadId, [FromRoute] long messageId, [FromQuery] int userId)
        {
            try
            {
                await _sql.ExecuteNonQueryAsync("dbo.sp_TogglePinMessage", p =>
                {
                    p.AddWithValue("@ThreadId", threadId);
                    p.AddWithValue("@MessageId", messageId);
                    p.AddWithValue("@UserId", userId);
                });

                return Ok(new { success = true });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpDelete("messages/{messageId}/for-me")]
        public async Task<IActionResult> DeleteForMe([FromRoute] long messageId, [FromQuery] int userId)
        {
            try
            {
                await _sql.ExecuteNonQueryAsync("dbo.sp_DeleteMessageForMe", p =>
                {
                    p.AddWithValue("@MessageId", messageId);
                    p.AddWithValue("@UserId", userId);
                });

                return Ok(new { success = true });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("threads/{threadId}/title")]
        public async Task<IActionResult> UpdateThreadTitle([FromRoute] long threadId, [FromQuery] int userId, [FromBody] UpdateTitleRequestDTO request)
        {
            var isMember = await _context.ThreadParticipants.AnyAsync(tp => tp.ThreadId == threadId && tp.UserId == userId);
            if (!isMember) return Forbid();

            var thread = await _context.ChatThreads.FirstOrDefaultAsync(t => t.Id == threadId);
            if (thread == null) return NotFound();

            thread.Title = request.NewTitle;
            await _context.SaveChangesAsync();

            return Ok(new { success = true, newTitle = thread.Title });
        }

        [HttpPost("threads/{threadId}/toggle-hide")]
        public async Task<IActionResult> ToggleHideThread([FromRoute] long threadId, [FromQuery] int userId)
        {
            try
            {
                await _sql.ExecuteNonQueryAsync("dbo.sp_ToggleHideThread", p =>
                {
                    p.AddWithValue("@ThreadId", threadId);
                    p.AddWithValue("@UserId", userId);
                });

                return Ok(new { success = true });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("threads/manage-participant")]
        public async Task<IActionResult> ManageParticipant([FromBody] ManageParticipantRequestDTO request, [FromQuery] int actionUserId)
        {
            try
            {
                await _sql.ExecuteNonQueryAsync("dbo.sp_ManageParticipant", p =>
                {
                    p.AddWithValue("@ThreadId", request.ThreadId);
                    p.AddWithValue("@ActionUserId", actionUserId);
                    p.AddWithValue("@TargetUserId", request.TargetUserId);
                    p.AddWithValue("@ActionType", request.ActionType);
                });

                return Ok(new { success = true });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("threads/{threadId}/roles")]
        public async Task<IActionResult> UpdateParticipantRole([FromRoute] long threadId, [FromQuery] int actionUserId, [FromBody] UpdateRoleRequestDTO request)
        {
            try
            {
                await _sql.ExecuteNonQueryAsync("dbo.sp_UpdateParticipantRole", p =>
                {
                    p.AddWithValue("@ThreadId", threadId);
                    p.AddWithValue("@ActionUserId", actionUserId);
                    p.AddWithValue("@TargetUserId", request.TargetUserId);
                    p.AddWithValue("@NewRole", request.NewRole);
                });

                return Ok(new { success = true });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("threads/{threadId}/mute")]
        public async Task<IActionResult> MuteThread([FromRoute] long threadId, [FromQuery] int userId, [FromBody] MuteThreadRequestDTO request)
        {
            try
            {
                await _sql.ExecuteNonQueryAsync("dbo.sp_MuteThread", p =>
                {
                    p.AddWithValue("@ThreadId", threadId);
                    p.AddWithValue("@UserId", userId);
                    p.AddWithValue("@IsMuted", request.IsMuted);
                    p.AddWithValue("@MutedUntilUTC", (object?)request.MutedUntilUTC ?? DBNull.Value);
                });

                return Ok(new { success = true });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("messages/{messageId}/attachments")]
        public async Task<IActionResult> SaveAttachment([FromRoute] long messageId, [FromBody] SaveAttachmentRequestDTO request)
        {
            try
            {
                // [Hạ tầng chung] Đây là chỗ DUY NHẤT còn dùng câu SQL thuần
                // (chưa có SP tương ứng) - vẫn qua ISqlDataAccess.ExecuteRawNonQueryAsync
                // và vẫn tham số hóa toàn bộ giá trị, không ghép chuỗi trực tiếp.
                const string sql = @"INSERT INTO dbo.MessageAttachment (MessageId, FileUrl, FileType, FileSize)
                                     VALUES (@MessageId, @FileUrl, @FileType, @FileSize);";

                await _sql.ExecuteRawNonQueryAsync(sql, p =>
                {
                    p.AddWithValue("@MessageId", messageId);
                    p.AddWithValue("@FileUrl", request.FileUrl);
                    p.AddWithValue("@FileType", request.FileType);
                    p.AddWithValue("@FileSize", request.FileSize);
                });

                return Ok(new { success = true });
            }
            catch (SqlException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
