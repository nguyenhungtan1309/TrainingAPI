using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TrainingAPI.DTOs;
using TrainingAPI.Models;
using TrainingAPI.Models.Users;
using TrainingAPI.Services.Common;

namespace TrainingAPI.Controllers
{
    [ApiController]
    [Route("api/v1/auth")]
    public class AuthController : ControllerBase
    {
        private readonly CompanyContext _context;
        private readonly IPasswordHasher _passwordHasher;
        private readonly IJwtTokenService _jwtTokenService;

        // [2.2 - đợt sau sẽ giải thích đầy đủ] Constructor Injection:
        // AuthController không còn tự viết ComputeSha256Hash/GenerateJwtToken
        // nữa, mà NHẬN các khả năng đó từ bên ngoài qua interface.
        public AuthController(CompanyContext context, IPasswordHasher passwordHasher, IJwtTokenService jwtTokenService)
        {
            _context = context;
            _passwordHasher = passwordHasher;
            _jwtTokenService = jwtTokenService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequestDTO request)
        {
            var userExists = await _context.AppUsers.AnyAsync(u => u.Username.ToLower() == request.Username.ToLower());
            if (userExists)
            {
                return BadRequest(new { message = "Tên đăng nhập này đã được sử dụng." });
            }

            var salt = _passwordHasher.GenerateSalt();
            var hash = _passwordHasher.Hash(request.Password, salt);

            // [2.1][Encapsulation] Không còn "new AppUser { ... }" gán property
            // tràn lan - constructor của AppUser tự validate, không thể tạo ra
            // một AppUser thiếu username/displayName/mật khẩu.
            var newUser = new AppUser(request.Username, request.DisplayName, hash, salt);

            _context.AppUsers.Add(newUser);
            await _context.SaveChangesAsync();

            return Ok(new { success = true, message = "Đăng ký tài khoản thành công!" });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequestDTO request)
        {
            var user = await _context.AppUsers.FirstOrDefaultAsync(u => u.Username.ToLower() == request.Username.ToLower());

            if (user == null || !user.IsActive || !_passwordHasher.Verify(request.Password, user.PasswordSalt, user.PasswordHash))
            {
                return BadRequest(new { message = "Tài khoản hoặc mật khẩu không chính xác." });
            }

            var token = _jwtTokenService.GenerateAccessToken(user);

            return Ok(new
            {
                token,
                userId = user.Id,
                username = user.Username,
                displayName = user.DisplayName,
                avatarUrl = user.AvatarUrl
            });
        }
    }
}
